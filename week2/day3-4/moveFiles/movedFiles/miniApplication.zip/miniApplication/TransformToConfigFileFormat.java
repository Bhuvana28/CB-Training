package miniApplication;

import java.io.*;

import org.apache.commons.csv.CSVRecord;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;  
import org.json.simple.parser.ParseException;  

import java.util.HashMap;
import java.util.ArrayList;

public class TransformToConfigFileFormat{

	public static void transformValueFormat(CSVRecord record){
		JSONParser parser = new JSONParser();
		System.out.println("Hello");

		try{
			JSONObject obj = (JSONObject)parser.parse(new BufferedReader(new FileReader("miniApplication/config.json"))); 
			HashMap<String,String> csvRecordMap = (HashMap<String,String>)record.toMap();

			ArrayList<String> formattedValues = new ArrayList<String>();

			for(String heading : csvRecordMap.keySet()){
				String jsonValue;
				try{
					jsonValue = (String)obj.get(heading);	

				}catch(JSONException jsonexcp){
					System.out.println(record.get(heading));
					formattedValues.add(record.get(heading));
				}
			}

		}catch (FileNotFoundException e) {  
			System.out.println("File not found");
   			e.printStackTrace();  
  		}catch (IOException e) {  
   			e.printStackTrace();  
  		}catch (ParseException e) {  
   			e.printStackTrace();  
  		}		  
	}
	
}
